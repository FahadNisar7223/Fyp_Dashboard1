import * as React from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import Button from '@mui/material/Button';
import Box from '@mui/material/Box';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select, { SelectChangeEvent } from '@mui/material/Select';
// function createData(name: string, calories: number, fat: number, carbs: number, protein: number) {
//   return { name, calories, fat, carbs, protein };
// }

// const rows = [
//   createData('Frozen yoghurt', 159, 6.0, 24, 4.0),
//   createData('Ice cream sandwich', 237, 9.0, 37, 4.3),
//   createData('Eclair', 262, 16.0, 24, 6.0),
//   createData('Cupcake', 305, 3.7, 67, 4.3),
//   createData('Gingerbread', 356, 16.0, 49, 3.9),
// ];

export default function HistoryPage() {
  return (
    <TableContainer component={Paper}>
      <Table sx={{ minWidth: 650 }} aria-label="simple table">
        <TableHead>
          <TableRow>
            <TableCell>
              <h3>Created By</h3>
            </TableCell>
            <TableCell>
              <h3>Assigned To</h3>
            </TableCell>
            <TableCell>
              <h3>Status</h3>
            </TableCell>
            <TableCell>
              <h3>Category</h3>
            </TableCell>
            <TableCell>
              <h3>Starting Time</h3>
            </TableCell>
            <TableCell>
              <h3>Ending Time</h3>
            </TableCell>
          </TableRow>
        </TableHead>

        {/* Body Work start */}
        <TableBody>
          <TableRow key={1} sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
            <TableCell component="th" scope="row">
              <b> Fahad</b>
            </TableCell>
            <TableCell>Moiz</TableCell>
            <TableCell>Start</TableCell>
            <TableCell>Carpentor</TableCell>

            <TableCell>11:20</TableCell>
            <TableCell>12:20</TableCell>
          </TableRow>
          <TableRow key={1} sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
            <TableCell component="th" scope="row">
              <b> Fahad</b>
            </TableCell>
            <TableCell>Moiz</TableCell>
            <TableCell>Start</TableCell>
            <TableCell>Carpentor</TableCell>

            <TableCell>11:20</TableCell>
            <TableCell>12:20</TableCell>
          </TableRow>
          <TableRow key={1} sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
            <TableCell component="th" scope="row">
              <b> Fahad</b>
            </TableCell>
            <TableCell>Moiz</TableCell>
            <TableCell>Start</TableCell>
            <TableCell>Carpentor</TableCell>

            <TableCell>11:20</TableCell>
            <TableCell>12:20</TableCell>
          </TableRow>
        </TableBody>
      </Table>
    </TableContainer>
  );
}
